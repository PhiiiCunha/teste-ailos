﻿using Questao5.Domain.Entities;
using Questao5.Domain.Enumerators;
using Questao5.Infrastructure.Database.QueryStore.Requests;
using Questao5.Infrastructure.Database.Repository.InterfacesRepository;
using Questao5.Infrastructure.Services.InterfacesService;

namespace Questao5.Infrastructure.Services
{
    public class MovimentacaoContaCorrenteService : IMovimentacaoContaCorrenteService
    {
        private readonly IMovimentacaoRepository _movimentacaoRepository;
        private readonly IContaCorrenteRepository _contaCorrenteRepository;

        public MovimentacaoContaCorrenteService(IMovimentacaoRepository movimentacaoRepository, IContaCorrenteRepository contaCorrenteRepository)
        {
            _movimentacaoRepository = movimentacaoRepository;
            _contaCorrenteRepository = contaCorrenteRepository;
        }

        public async Task<Resultado> InsereMovimentacao(MovimentoRequest movimentoRequest)
        {
            try
            {
                if (movimentoRequest.contaCorrente < 1 || await _contaCorrenteRepository.GetContaCorrente(movimentoRequest.contaCorrente) == false)
                    return new Resultado { Codigo = StatusCodes.Status400BadRequest, Mensagem = Mensagens.INVALID_ACCOUNT.ToString() };

                if (await _contaCorrenteRepository.GetStatusContaCorrente(movimentoRequest.contaCorrente, true) == false)
                    return new Resultado { Codigo = StatusCodes.Status400BadRequest, Mensagem = Mensagens.INACTIVE_ACCOUNT.ToString() };

                if (movimentoRequest.valor < 1)
                    return new Resultado { Codigo = StatusCodes.Status400BadRequest, Mensagem = Mensagens.INVALID_VALUE.ToString() };

                if (movimentoRequest.tipoMovimento != 'C' && movimentoRequest.tipoMovimento != 'D')
                    return new Resultado { Codigo = StatusCodes.Status400BadRequest, Mensagem = Mensagens.INVALID_TYPE.ToString() };

                var idContacorrente = await _contaCorrenteRepository.GetIdContaCorrente(movimentoRequest.contaCorrente);

                var movimento = new Movimento 
                {
                    IdContaCorrente = idContacorrente,
                    DataMovimento = DateTime.Now.ToString(),
                    TipoMovimento = movimentoRequest.tipoMovimento.ToString(),
                    Valor = movimentoRequest.valor
                };

                var resultado = await _movimentacaoRepository.InsertMovimentacao(movimento);

                if (resultado == null || resultado.Codigo != 200)
                    return new Resultado { Codigo = StatusCodes.Status400BadRequest, Mensagem = resultado.Mensagem };

                movimento.IdMovimento = resultado.Retorno.ToString();
                return new Resultado { Codigo = StatusCodes.Status200OK, Mensagem = null, Retorno = movimento };

            }
            catch (HttpRequestException ex)
            {
                return new Resultado { Codigo = (int)ex.StatusCode, Mensagem = ex.Message };
            }
            catch (Exception ex)
            {
                return new Resultado { Codigo = StatusCodes.Status500InternalServerError, Mensagem = ex.Message };
            }
        }
    }
}