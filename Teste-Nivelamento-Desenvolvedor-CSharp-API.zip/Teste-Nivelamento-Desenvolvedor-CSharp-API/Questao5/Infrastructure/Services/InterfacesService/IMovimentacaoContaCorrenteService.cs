﻿using Questao5.Domain.Entities;
using Questao5.Infrastructure.Database.QueryStore.Requests;

namespace Questao5.Infrastructure.Services.InterfacesService
{
    public interface IMovimentacaoContaCorrenteService
    {
        Task<Resultado> InsereMovimentacao(MovimentoRequest movimentoRequest);
    }
}