﻿using Questao5.Domain.Entities;

namespace Questao5.Infrastructure.Services.InterfacesService
{
    public interface IContaCorrenteService
    {
        Task<Resultado> SaldoContaCorrente(int numeroConta);
    }
}