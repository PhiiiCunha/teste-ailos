using Microsoft.AspNetCore.Mvc;
using Questao5.Infrastructure.Database.QueryStore.Requests;
using Questao5.Infrastructure.Services.InterfacesService;

namespace Questao5.Infrastructure.Services.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IContaCorrenteService _contaCorrenteService;
        private readonly IMovimentacaoContaCorrenteService _movimentacaoContaCorrenteService;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IContaCorrenteService contaCorrenteService, IMovimentacaoContaCorrenteService movimentacaoContaCorrenteService)
        {
            _logger = logger;
            _contaCorrenteService = contaCorrenteService;
            _movimentacaoContaCorrenteService = movimentacaoContaCorrenteService;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpGet(Name = "MovimentacaoContaCorrente")]
        public async Task<IActionResult> GetMovimentacaoContaCorrente([FromBody] MovimentoRequest request)
        {
            var response = await _movimentacaoContaCorrenteService.InsereMovimentacao(request);

            if (response.Codigo == StatusCodes.Status200OK)
                return Ok(response);
            else
                return BadRequest(response);
        }

        [HttpGet(Name = "SaldoContaCorrente")]
        public async Task<IActionResult> GetSaldoContaCorrente([FromBody] int numeroConta)
        {
            var response = await _contaCorrenteService.SaldoContaCorrente(numeroConta);

            if (response.Codigo == StatusCodes.Status200OK)
                return Ok(response);
            else
                return BadRequest(response);
        }
    }
}