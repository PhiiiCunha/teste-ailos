﻿using NSubstitute;
using Questao5.Domain.Entities;
using Questao5.Domain.Enumerators;
using Questao5.Infrastructure.Database.QueryStore.Requests;
using Questao5.Infrastructure.Database.QueryStore.Responses;
using Questao5.Infrastructure.Database.Repository;
using Questao5.Infrastructure.Database.Repository.InterfacesRepository;
using Questao5.Infrastructure.Services.InterfacesService;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Questao5.Infrastructure.Services
{
    public class ContaCorrenteService : IContaCorrenteService
    {
        private readonly IMovimentacaoRepository _movimentacaoRepository;
        private readonly IContaCorrenteRepository _contaCorrenteRepository;

        public ContaCorrenteService(IMovimentacaoRepository movimentacaoRepository, IContaCorrenteRepository contaCorrenteRepository)
        {
            _movimentacaoRepository = movimentacaoRepository;
            _contaCorrenteRepository = contaCorrenteRepository;
        }

        public async Task<Resultado> SaldoContaCorrente(int numeroConta)
        {
            try
            {
                if (numeroConta < 1 || await _contaCorrenteRepository.GetContaCorrente(numeroConta) == false)
                    return new Resultado { Codigo = StatusCodes.Status400BadRequest, Mensagem = Mensagens.INVALID_ACCOUNT.ToString() };

                if (await _contaCorrenteRepository.GetStatusContaCorrente(numeroConta, true) == false)
                    return new Resultado { Codigo = StatusCodes.Status400BadRequest, Mensagem = Mensagens.INACTIVE_ACCOUNT.ToString() };

                var saldoContaCorrenteResponse = new SaldoContaCorrenteResponse { NumeroContaCorrente = numeroConta, DataHoraConsulta = DateTime.Now, SaldoAtual = 0 };

                var movimentacoes = await _movimentacaoRepository.GetMovimentacaoPorContaCorrente(numeroConta);

                if (movimentacoes == null || !movimentacoes.Any())
                    return new Resultado { Codigo = StatusCodes.Status400BadRequest, Retorno = saldoContaCorrenteResponse };

                var movimentacaoCredito = movimentacoes.Where(w => w.TipoMovimento == "C").Select(x => x.Valor).Sum();
                var movimentacaoDebito = movimentacoes.Where(w => w.TipoMovimento == "D").Select(x => x.Valor).Sum();

                saldoContaCorrenteResponse.SaldoAtual = movimentacaoCredito - movimentacaoDebito;

                return new Resultado { Codigo = StatusCodes.Status200OK, Retorno = saldoContaCorrenteResponse }; ;
            }
            catch (HttpRequestException ex)
            {
                return new Resultado { Codigo = (int)ex.StatusCode, Mensagem = ex.Message };
            }
            catch (Exception ex)
            {
                return new Resultado { Codigo = StatusCodes.Status500InternalServerError, Mensagem = ex.Message };
            }
        }
    }
}