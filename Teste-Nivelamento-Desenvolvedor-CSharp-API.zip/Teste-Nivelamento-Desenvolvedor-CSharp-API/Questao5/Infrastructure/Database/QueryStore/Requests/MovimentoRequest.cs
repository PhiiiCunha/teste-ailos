﻿namespace Questao5.Infrastructure.Database.QueryStore.Requests
{
    public class MovimentoRequest
    {
        public string requisicao { get; set; }
        public int contaCorrente { get; set; }
        public double valor { get; set; }
        public char tipoMovimento { get; set; }
    }
}
