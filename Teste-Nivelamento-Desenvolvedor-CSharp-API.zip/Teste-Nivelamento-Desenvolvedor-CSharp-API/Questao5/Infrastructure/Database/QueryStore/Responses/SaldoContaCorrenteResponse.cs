﻿namespace Questao5.Infrastructure.Database.QueryStore.Responses
{
    public class SaldoContaCorrenteResponse
    {
        public int NumeroContaCorrente { get; set; }
        public string NomeTitular { get; set; }
        public DateTime DataHoraConsulta { get; set; }
        public double SaldoAtual { get; set; }
    }
}