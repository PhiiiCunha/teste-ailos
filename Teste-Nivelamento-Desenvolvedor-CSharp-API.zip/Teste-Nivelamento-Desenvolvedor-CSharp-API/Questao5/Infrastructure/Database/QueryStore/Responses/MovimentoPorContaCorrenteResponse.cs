﻿namespace Questao5.Infrastructure.Database.QueryStore.Responses
{
    public class MovimentoPorContaCorrenteResponse
    {
        public int NumeroContaCorrente { get; set; }
        public string Nome { get; set; }
        public string TipoMovimento { get; set; }
        public double Valor { get; set; }
    }
}
