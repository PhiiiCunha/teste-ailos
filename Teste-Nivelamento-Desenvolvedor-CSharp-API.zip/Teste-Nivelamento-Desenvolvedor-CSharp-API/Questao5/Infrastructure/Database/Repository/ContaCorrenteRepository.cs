﻿using Dapper;
using Microsoft.Data.Sqlite;
using Questao5.Infrastructure.Database.Repository.InterfacesRepository;
using Questao5.Infrastructure.Sqlite;
using System.Text;

namespace Questao5.Infrastructure.Database.Repository
{
    public class ContaCorrenteRepository : IContaCorrenteRepository
    {

        public async Task<bool> GetContaCorrente(int numeroConta)
        {
            try
            {
                var query = new StringBuilder();

                query.Append("SELECT * FROM ContaCorrente WHERE numero = @NumeroContaCorrente");

                var connection = new SqliteConnection("");

                return await connection.QueryFirstOrDefaultAsync<bool>(query.ToString(), new { NumeroContaCorrente = numeroConta });
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<string> GetIdContaCorrente(int numeroConta)
        {
            try
            {
                var query = new StringBuilder();

                query.Append("SELECT idcontacorrente FROM ContaCorrente WHERE numero = @NumeroContaCorrente");

                var connection = new SqliteConnection("");

                return await connection.QueryFirstOrDefaultAsync<string>(query.ToString(), new { NumeroContaCorrente = numeroConta });
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<bool> GetStatusContaCorrente(int numeroConta, bool contaAtiva)
        {
            try
            {
                var query = new StringBuilder();

                query.Append("SELECT * FROM ContaCorrente WHERE numero = @NumeroContaCorrente AND ativo = @StatusConta");

                var connection = new SqliteConnection("");

                return await connection.QueryFirstOrDefaultAsync<bool>(query.ToString(), new { NumeroContaCorrente = numeroConta, StatusConta = contaAtiva });
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}