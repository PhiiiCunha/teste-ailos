﻿namespace Questao5.Infrastructure.Database.Repository.InterfacesRepository
{
    public interface IContaCorrenteRepository
    {
        Task<bool> GetContaCorrente(int numeroConta);
        Task<string> GetIdContaCorrente(int numeroConta);
        Task<bool> GetStatusContaCorrente(int numeroConta, bool contaAtiva);
    }
}