﻿using Questao5.Domain.Entities;
using Questao5.Infrastructure.Database.QueryStore.Responses;

namespace Questao5.Infrastructure.Database.Repository.InterfacesRepository
{
    public interface IMovimentacaoRepository
    {
        Task<Resultado> InsertMovimentacao(Movimento movimento);
        Task<IEnumerable<MovimentoPorContaCorrenteResponse>> GetMovimentacaoPorContaCorrente(int numeroConta);
    }
}