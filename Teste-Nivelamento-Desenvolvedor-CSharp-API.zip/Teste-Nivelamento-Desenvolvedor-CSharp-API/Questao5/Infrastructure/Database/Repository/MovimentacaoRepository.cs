﻿using Dapper;
using Microsoft.Data.Sqlite;
using Questao5.Domain.Entities;
using Questao5.Infrastructure.Database.QueryStore.Requests;
using Questao5.Infrastructure.Database.QueryStore.Responses;
using Questao5.Infrastructure.Database.Repository.InterfacesRepository;
using System.Data;
using System.Text;

namespace Questao5.Infrastructure.Database.Repository
{
    public class MovimentacaoRepository : IMovimentacaoRepository
    {
        public async Task<Resultado> InsertMovimentacao(Movimento movimento)
        {
            try
            {
                var query = new StringBuilder();

                query.Append("INSERT INTO movimento ");
                query.Append("(idcontacorrente, ");
                query.Append("datamovimento, ");
                query.Append("tipomovimento, ");
                query.Append("valor ");
                query.Append(") VAUES (");
                query.Append("(@IdContaCorrente, ");
                query.Append("@DataMovimento, ");
                query.Append("@TipoMovimento, ");
                query.Append("@Valor )");

                var connection = new SqliteConnection("connection string");

                var idMovimento = await connection.QueryFirstOrDefaultAsync<string>(query.ToString(), movimento, commandType: CommandType.Text);

                return new Resultado { Codigo = 200, Mensagem = null, Retorno = idMovimento };
            }
            catch (Exception ex)
            {
                return new Resultado { Codigo = 999, Retorno = null, Mensagem = ex.Message };
            }
        }

        public async Task<IEnumerable<MovimentoPorContaCorrenteResponse>> GetMovimentacaoPorContaCorrente(int numeroConta)
        {
            try
            {
                var query = new StringBuilder();

                query.Append("SELECT cc.numero AS NumeroContaCorrente, cc.Nome, m.TipoMovimento, m.Valor ");
                query.Append("FROM ContaCorrente cc ");
                query.Append("INNER JOIN movimento m ON m.idcontacorrente = cc.idcontacorrente ");
                query.Append("WHERE numero = @NumeroConta ");
                query.Append("AND m.datamovimento <= @DataCorrente");

                var connection = new SqliteConnection("");

                return await connection.QueryAsync<MovimentoPorContaCorrenteResponse>(query.ToString(), new { NumeroConta = numeroConta, DataCorrente = DateTime.Now.ToString() });
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
