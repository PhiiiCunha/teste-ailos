﻿namespace Questao5.Domain.Entities
{
    public class Resultado
    {
        public Resultado()
        {

        }

        public Resultado(int codigo, string mensagem, object retorno)
        {
            codigo = codigo;
            mensagem = Mensagem;
            retorno = Retorno;
        }

        public int? Codigo { get; set; }
        public string Mensagem { get; set; }
        public object Retorno { get; set; }
    }
}
