﻿using System.Globalization;

namespace Questao1
{
    class ContaBancaria {

        public int conta;
        public string titular;
        public double saldo = 0;
        private double taxaSaque = 3.50;

        public ContaBancaria(int numeroConta, string nomeTitular, double valorDeposito)
        {
            conta = numeroConta;
            titular = nomeTitular;
            saldo = valorDeposito;
        }

        public ContaBancaria(int numeroConta, string nomeTitular)
        {
            conta = numeroConta;
            titular = nomeTitular;
        }

        public double Deposito(double valorDepositado)
        {
            return saldo += valorDepositado;
        }

        public double Saque(double valorSaque)
        {
            saldo = saldo - valorSaque - taxaSaque;

            return saldo;
        }
        public string GetDadosConta()
        {
            return $"Conta {conta}, Titular: {titular}, Saldo: R$ {saldo}";
        }
    }
}
