﻿using Newtonsoft.Json;
using System;

public class Program
{
    public static void Main()
    {
        /*
         MESMO FAZENDO A REQUISICAO DUAS VEZES, FILTRANDO POR TIME 1 E TIME 2 ELE RETORNOU MENOS GOLS DO QUE O RESULTADO ESPERADO
        FIZ O TESTE EM MEU NAVEGADOR PARA CONSTAR QUE REALMENTE ESTAVA RETORNANDO MENOS.
         */


        string teamName = "Paris Saint-Germain";
        int year = 2013;
        int totalGoals = getTotalScoredGoals(teamName, year);

        Console.WriteLine("Team " + teamName + " scored " + totalGoals.ToString() + " goals in " + year);

        teamName = "Chelsea";
        year = 2014;
        totalGoals = getTotalScoredGoals(teamName, year);

        Console.WriteLine("Team " + teamName + " scored " + totalGoals.ToString() + " goals in " + year);

        // Output expected:
        // Team Paris Saint - Germain scored 109 goals in 2013
        // Team Chelsea scored 92 goals in 2014
    }

    public static int getTotalScoredGoals(string team, int year)
    {
        var totalGols = 0;
        using (var client = new HttpClient())
        {
            var response = client.GetAsync($"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team1={team}").Result;

            if (response.IsSuccessStatusCode)
            {
                var json = response.Content.ReadAsStringAsync().Result;
                var resultado = JsonConvert.DeserializeObject<Retorno>(json);

                if (resultado != null && resultado.data.Any())
                {
                    foreach (var item in resultado.data)
                    {
                        totalGols += Convert.ToInt32(item.team1goals);
                    }
                }
            }

            var response2 = client.GetAsync($"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team2={team}").Result;

            if (response2.IsSuccessStatusCode)
            {
                var json = response2.Content.ReadAsStringAsync().Result;
                var resultado = JsonConvert.DeserializeObject<Retorno>(json);

                if (resultado != null && resultado.data.Any())
                {
                    foreach (var item in resultado.data)
                    {
                        totalGols += Convert.ToInt32(item.team2goals);
                    }
                }
            }
        }

        return totalGols;
    }

    public class Retorno
    {
        public int page { get; set; }
        public int per_page { get; set; }
        public int total { get; set; }
        public int total_pages { get; set; }
        public List<Times> data { get; set; }

    }

    public class Times
    {
        public string competition { get; set; }
        public int year { get; set; }
        public string round { get; set; }
        public string team1 { get; set; }
        public string team2 { get; set; }
        public string team1goals { get; set; }
        public string team2goals { get; set; }
    }

}